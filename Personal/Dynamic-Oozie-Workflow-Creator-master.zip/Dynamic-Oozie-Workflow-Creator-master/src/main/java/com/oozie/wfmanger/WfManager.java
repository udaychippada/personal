package com.oozie.wfmanger;

import java.io.IOException;

public interface WfManager {	
	/**
	 * 
	 * @return
	 * @throws IOException
	 */
	public String generateWorkFlow() throws IOException;
}
