
//@javax.xml.bind.annotation.XmlSchema(namespace = "", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
@XmlSchema(namespace = "uri:oozie:workflow:0.2",elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED,xmlns = { @javax.xml.bind.annotation.XmlNs(namespaceURI = "uri:oozie:workflow:0.2", prefix = "") })
package com.oozie.components;
import javax.xml.bind.annotation.XmlSchema;

